// src/theme.ts
import { createTheme } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: { main: "#003366" }, // Navy
    secondary: { main: "#FFD700" }, // Gold
    background: {
      default: "#0A1F44", // Dark blue background
      paper: "#FFFFFF", // White for cards
    },
    text: {
      primary: "#003366", // Navy for text
    },
  },
});

export default theme;