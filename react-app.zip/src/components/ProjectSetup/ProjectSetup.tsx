import React, { useState } from "react";
import { Button, TextField, Box } from "@mui/material";

const ProjectSetup: React.FC = () => {
  const [projectName, setProjectName] = useState("");

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setProjectName(event.target.value);
  };

  const handleSubmit = () => {
    console.log("Project Created:", projectName);
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        gap: 2,
        maxWidth: 400,
        margin: "auto",
        padding: 3,
        border: "1px solid #ddd",
        borderRadius: "8px",
        boxShadow: 2,
      }}
    >
      <h2>Project Setup</h2>
      <TextField
        label="Project Name"
        variant="outlined"
        value={projectName}
        onChange={handleChange}
        fullWidth
      />
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Create Project
      </Button>
    </Box>
  );
};

export default ProjectSetup;
