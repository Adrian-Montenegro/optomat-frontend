// src/components/MaterialSelection/MaterialSelection.tsx
import { useState } from "react";
import { Button, Select, MenuItem, FormControl, InputLabel, Typography, Box } from "@mui/material";

const MaterialSelection = ({ nextStep, prevStep }: { nextStep: () => void; prevStep: () => void }) => {
  const [selectedMaterial, setSelectedMaterial] = useState("");

  const materials = [
    { name: "Concrete A", sustainability: 90, cost: 80, durability: 70 },
    { name: "Concrete B", sustainability: 70, cost: 60, durability: 80 },
  ];

  return (
    <Box
      sx={{
        width: "100%",
        maxWidth: "600px",
        padding: "2rem",
        backgroundColor: "background.paper",
        borderRadius: "8px",
        boxShadow: 3,
      }}
    >
      <Typography variant="h5" gutterBottom sx={{ color: "text.primary" }}>
        AI-Recommended Materials
      </Typography>
      <FormControl fullWidth sx={{ marginBottom: "1rem" }}>
        <InputLabel>Select Material</InputLabel>
        <Select value={selectedMaterial} onChange={(e) => setSelectedMaterial(e.target.value)}>
          {materials.map((mat, index) => (
            <MenuItem key={index} value={mat.name}>
              {mat.name} (S: {mat.sustainability}, C: {mat.cost}, D: {mat.durability})
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <Box sx={{ display: "flex", justifyContent: "space-between" }}>
        <Button onClick={prevStep}>Back</Button>
        <Button variant="contained" color="primary" onClick={nextStep}>
          Next
        </Button>
      </Box>
    </Box>
  );
};

export default MaterialSelection;