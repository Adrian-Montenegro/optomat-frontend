import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ThemeProvider, CssBaseline, Container } from "@mui/material";
import ProjectSetup from "./components/ProjectSetup/ProjectSetup";
import MaterialSelection from "./components/MaterialSelection/MaterialSelection";
import Evaluation from "./components/Evaluation/Evaluation";
import FinalReport from "./components/FinalReport/FinalReport";
import theme from "./theme/theme";

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Container
          maxWidth="md"
          sx={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "100vh",
            padding: "2rem",
          }}
        >
          <Routes>
            <Route path="/" element={<ProjectSetup />} />
            <Route path="/material-selection" element={<MaterialSelection nextStep={function (): void {
              throw new Error("Function not implemented.");
            } } prevStep={function (): void {
              throw new Error("Function not implemented.");
            } } />} />
            <Route path="/evaluation" element={<Evaluation nextStep={() => {}} prevStep={() => {}} />} />
            <Route path="/final-report" element={<FinalReport prevStep={() => {}} />} />
          </Routes>
        </Container>
      </Router>
    </ThemeProvider>
  );
}

export default App;
